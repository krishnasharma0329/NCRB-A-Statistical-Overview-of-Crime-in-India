#import all lib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# Load the NCRB Dataset
df = pd.read_csv(r"C:\Users\User\Downloads\NCRB-2021_Table_17A.1.csv")
# Preview the dataset
print("First 5 entries:\n", df.head())

# Print complete information about the dataset
print("=== Dataset Info ===")
print(df.info())
# Print top 5 rows
print("\n=== Top 5 Rows ===")
print(df.head())
# Print bottom 5 rows
print("\n=== Bottom 5 Rows ===")
print(df.tail())
# Print complete statistical summary (only for numerical columns)
print("\n=== Statistical Summary ===")
print(df.describe())
# Count of null values in each column
print("\n=== Null Values in Each Column ===")
print(df.isnull().sum())
# Count of duplicated rows
print("\n=== Number of Duplicate Rows ===")
print(df.duplicated().sum())
# Shape of the dataset
print("\n=== Shape of DataFrame ===")
print(df.shape)


#graph of sheet
df.hist(figsize=(10, 5), bins=30, color='skyblue', edgecolor='black')
plt.show()


#heat map
df_numeric = df.select_dtypes(include=['number'])
plt.figure(figsize=(12, 6))
sns.heatmap(df_numeric.corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Matrix of total cases")
plt.show()

#trend ======
df['Cases Reported during the year - Col. (4)'] = pd.to_datetime(df['Cases Reported during the year - Col. (4)'])
plt.figure(figsize=(15, 8))
sns.lineplot(x='Cases Reported during the year - Col. (4)', y='Cases Pending Investigation from Previous Year - Col. (3)', data=df, color="blue")
plt.xlabel("Cases Pending Investigation from Previous Year")
plt.ylabel("Cases Pending Investigation from Previous Year")
plt.title("case trend over time")
plt.show()

plt.figure(figsize=(10, 6))
sns.histplot(df["Cases Reported during the year - Col. (4)"], bins=50, kde=True, color='blue')
plt.title("Cases Reported during the year - Col. (4)")
plt.xlabel("Cases Reported during the year")
plt.ylabel("Cases Reported during the year")
plt.show()


# Scatter plot
plt.figure(figsize=(10, 6))
plt.scatter(df['Cases Reopened for Investigation - Col. (5)'], df['Cases Reopened for Investigation - Col. (5)'], color='red', alpha=0.6)
plt.xlabel("Cases Reopened for Investigation")
plt.ylabel("Cases Reopened for Investigation")
plt.title("crime case")
plt.show()





